package Main;
import national.NationalService;
import international.InternationalService;

import java.util.Scanner;

public class PostOfficeSystem {
      Scanner scanner = new Scanner(System.in);
      NationalService nationalService = new NationalService();
      InternationalService internationalService = new InternationalService();

    public void displayMenu() {
        while (true) {
            System.out.println("-------------------------------------");
            System.out.println("=== Post Office System ===");
            System.out.println("1. National Transfer");
            System.out.println("2. International Transfer");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> nationalService.handleNationalTransfer();
                case 2 -> internationalService.handleInternationalTransfer();
                case 3 -> {
                    System.out.println("Thank you for using the Post Office System. Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
