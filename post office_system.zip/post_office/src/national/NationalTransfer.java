package national;

public abstract class NationalTransfer {
    private static int idCounter = 1000; // Static counter for generating IDs
    protected int id;
    
    protected double height, width, weight;

    public NationalTransfer( double height, double width, double weight) {
        this.id = idCounter++;
        this.height = height;
        this.width = width;
        this.weight = weight;
    }

    public int getId() {
        return id;
    }

    public abstract double calculatePrice();
    public abstract String getDetails();
}
