package national;

import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

public class NationalService  {
    private final HashMap<Integer, NationalSend> transfers = new HashMap<>();
    private final Scanner scanner = new Scanner(System.in);

   

    public void handleNationalTransfer() {
        System.out.println("1. Send Item");
        System.out.println("2. Receive Item");
        int choice = scanner.nextInt();

        if (choice == 1) {
            handleSend();
        } else if (choice == 2) {
            handleReceive();
        } else {
            System.out.println("Invalid choice!");
        }
    }

  private void handleSend() {
    String[] Cities = {"Sulaymaniyah", "Erbil", "Kirkuk", "Duhok"};

    System.out.println("Choose From City (Sulaymaniyah, Erbil, Kirkuk, Duhok): ");
    String fromCity = getValidCity(Cities);

    System.out.println("Choose To City (Sulaymaniyah, Erbil, Kirkuk, Duhok): ");
    String toCity = getValidCity(Cities);

    System.out.print("Sender Name: ");
    String senderName = scanner.next();
    System.out.print("Sender Phone: ");
    String senderPhone = scanner.next();

    System.out.print("Receiver Name: ");
    String receiverName = scanner.next();
    System.out.print("Receiver Phone: ");
    String receiverPhone = scanner.next();

    System.out.print("Delivery (true/false): ");
    boolean delivery = scanner.nextBoolean();

    String deliveryStreet = "";
    if (delivery) {
        System.out.print("Enter Delivery Street: ");
        deliveryStreet = scanner.next();
    }

    System.out.print("Height: ");
    double height = scanner.nextDouble();
    System.out.print("Width: ");
    double width = scanner.nextDouble();
    System.out.print("Weight: ");
    double weight = scanner.nextDouble();

   
    NationalSend transfer = new NationalSend( fromCity, toCity, delivery, deliveryStreet, senderName, senderPhone, receiverName, receiverPhone, height, width, weight);
           transfers.put(transfer.getId(), transfer);
       

    System.out.println("Transfer Created with ID: " + transfer.getId());
    System.out.println("Total Price: " + transfer.calculatePrice());
}

private String getValidCity(String[] validCities) {
    while (true) {
        String city = scanner.next();
        for (String validCity : validCities) {
            if (city.equalsIgnoreCase(validCity)) {
                return validCity; // Return the city if valid
            }
        }
        System.out.println("Invalid city! Please choose one of the following: Sulaymaniyah, Erbil, Kirkuk, Duhok");
    }
}

    private void handleReceive() {
        System.out.print("Enter Transfer ID: ");
        int id = scanner.nextInt();
        NationalSend transfer = transfers.get(id);
        if (transfer == null) {
            System.out.println("No transfer found with this ID.");
        } else {
            System.out.println(transfer.getDetails());
            System.out.print("Delete this transfer? (yes/no): ");
            String  delete = scanner.next();
          
            if (delete.equalsIgnoreCase("yes")) {
                transfers.remove(id);
                System.out.println("Transfer deleted.");}
                else if (delete.equalsIgnoreCase("no")){
                       return;
                        }
        }
    }
}
