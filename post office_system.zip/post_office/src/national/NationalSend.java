package national;

public class NationalSend extends NationalTransfer {
    private String fromCity;
    private String toCity;
    private boolean delivery;
    private String deliveryStreet;
    private String senderName;
    private String senderPhone;
    private String receiverName;
    private String receiverPhone;

    public NationalSend( String fromCity, String toCity, boolean delivery, String deliveryStreet, String senderName, String senderPhone, String receiverName, String receiverPhone, double height, double width, double weight) {
        super( height, width, weight);
        this.fromCity = fromCity;
        this.toCity = toCity;
        this.delivery = delivery;
        this.deliveryStreet = deliveryStreet;
        this.senderName = senderName;
        this.senderPhone = senderPhone;
        this.receiverName = receiverName;
        this.receiverPhone = receiverPhone;
    }

    @Override
    public double calculatePrice() {
        double basePrice = height * width * weight * 0.01;
        double distance = getDistance(fromCity, toCity);
        return delivery ? basePrice + distance * 0.05 + 5 : basePrice + distance * 0.05;
    }

    @Override
    public String getDetails() {
        return "National Transfer [ID: " + id +
                ", From: " + fromCity + ", To: " + toCity +
                ", Sender: " + senderName + " (" + senderPhone + ")" +
                ", Receiver: " + receiverName + " (" + receiverPhone + ")" +
                ", Delivery: " + (delivery ? "Yes (" + deliveryStreet + ")" : "No") +
                ", Price: " + calculatePrice() + "]";
    }

    private double getDistance(String fromCity, String toCity) {
      
        if ((fromCity.equals("Sulaymaniyah") && toCity.equals("Erbil")) || (fromCity.equals("Erbil") && toCity.equals("Sulaymaniyah"))) {
            return 200;
        } else if ((fromCity.equals("Sulaymaniyah") && toCity.equals("Duhok")) || (fromCity.equals("Duhok") && toCity.equals("Sulaymaniyah"))) {
            return 300;
        } else if ((fromCity.equals("Sulaymaniyah") && toCity.equals("Kirkuk")) || (fromCity.equals("Kirkuk") && toCity.equals("Sulaymaniyah"))) {
            return 150;
        } else {
            return 100; // Default distance for other cities
        }
    }

   
}
