package international;

public abstract class InternationalTransfer {
    protected static int idCounter = 1000; 
    protected int id;
    protected double height, width, weight;

    public InternationalTransfer(double height, double width, double weight) {
        this.id = idCounter++; 
        this.height = height;
        this.width = width;
        this.weight = weight;
    }

    public int getId() {
        return id;
    }

    public abstract double calculatePrice();
    public abstract String getDetails();
}
