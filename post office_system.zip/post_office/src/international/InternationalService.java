package international;

import java.util.HashMap;
import java.util.Scanner;

public class InternationalService {
    HashMap<Integer, InternationalSend> transfers = new HashMap<>();
    Scanner scanner = new Scanner(System.in);

    public void handleInternationalTransfer() {
        System.out.println("1. Send Item");
        System.out.println("2. Receive Item");
        int choice = scanner.nextInt();

        if (choice == 1) {
            handleSend();
        } else if (choice == 2) {
            handleReceive();
        } else {
            System.out.println("Invalid choice!");
        }
    }

    private void handleSend() {
        System.out.print("From Country: ");
        String fromCountry = scanner.next();
        System.out.print("From City: ");
        String fromCity = scanner.next();
        System.out.print("To Country: ");
        String toCountry = scanner.next();
        System.out.print("To City: ");
        String toCity = scanner.next();
        System.out.print("Send By (true for Plane, false for Truck): ");
        boolean byPlane = scanner.nextBoolean();

        // Capture sender and receiver details
        System.out.print("Sender Name: ");
        String senderName = scanner.next();
        System.out.print("Sender Phone: ");
        String senderPhone = scanner.next();
        System.out.print("Receiver Name: ");
        String receiverName = scanner.next();
        System.out.print("Receiver Phone: ");
        String receiverPhone = scanner.next();

        System.out.print("Height: ");
        double height = scanner.nextDouble();
        System.out.print("Width: ");
        double width = scanner.nextDouble();
        System.out.print("Weight: ");
        double weight = scanner.nextDouble();

        InternationalSend transfer = new InternationalSend(fromCountry, toCountry, fromCity, toCity, byPlane,
                                                           senderName, senderPhone, receiverName, receiverPhone,
                                                           height, width, weight);
        transfers.put(transfer.getId(), transfer);
        System.out.println("Transfer Created with ID: " + transfer.getId());
         System.out.println("Total Price: " + transfer.calculatePrice());
    }

    private void handleReceive() {
        System.out.print("Enter Transfer ID: ");
        int id = scanner.nextInt();
        InternationalSend transfer = transfers.get(id);
        if (transfer == null) {
            System.out.println("No transfer found with this ID.");
        } else {
            System.out.println(transfer.getDetails());
           
            System.out.print("Delete this transfer? (yes/no): ");
            String  delete = scanner.next();
          
            if (delete.equalsIgnoreCase("yes")) {
                transfers.remove(id);
                System.out.println("Transfer deleted.");}
                else if (delete.equalsIgnoreCase("no")){
                       return;
                        }
           
            
        }
    }
}
