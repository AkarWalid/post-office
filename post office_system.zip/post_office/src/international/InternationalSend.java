package international;

public class InternationalSend extends InternationalTransfer {
    private String fromCountry;
    private String toCountry;
    private String fromCity;
    private String toCity;
    private boolean byPlane;
    private String senderName;
    private String senderPhone;
    private String receiverName;
    private String receiverPhone;

    public InternationalSend(String fromCountry, String toCountry, String fromCity, String toCity, boolean byPlane, 
                             String senderName, String senderPhone, String receiverName, String receiverPhone,
                             double height, double width, double weight) {
        super(height, width, weight);
        this.fromCountry = fromCountry;
        this.toCountry = toCountry;
        this.fromCity = fromCity;
        this.toCity = toCity;
        this.byPlane = byPlane;
        this.senderName = senderName;
        this.senderPhone = senderPhone;
        this.receiverName = receiverName;
        this.receiverPhone = receiverPhone;
    }

    @Override
    public double calculatePrice() {
        double basePrice = height * width * weight * 0.02;
        double distance = getCountryDistance(fromCountry, toCountry);
        return byPlane ? basePrice + distance * 0.1 + 20 : basePrice + distance * 0.07;
    }

    private double getCountryDistance(String fromCountry, String toCountry) {
        // Simulated distances (you can add more mappings)
        if (fromCountry.equals(fromCountry) && toCountry.equals(toCountry)) return 500; // Same country
        return 1500; // Default for different countries
    }

    @Override
    public String getDetails() {
        return "International Transfer [ID: " + id +
                ", From: " + fromCountry + " (" + fromCity + ")" +
                ", To: " + toCountry + " (" + toCity + ")" +
                ", By: " + (byPlane ? "Plane" : "Truck") +
                ", Sender: " + senderName + " (" + senderPhone + ")" +
                ", Receiver: " + receiverName + " (" + receiverPhone + ")" +
                ", Price: " + calculatePrice() + "]";
    }
}
